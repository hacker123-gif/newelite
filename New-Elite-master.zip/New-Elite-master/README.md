# New-Elite

<ul>
<li><code>$ apt update && apt upgrade</code></li>
<li><code>$ pkg install python2</code></li>
<li><code>$ pip2 install mechanize</code></li>
<li><code>$ pip2 install requests</code></li>
<li><code>$ pkg install git</code></li>
<li><code>$ git clone https://github.com/MrDebo/New-Elite</code></li>
<li><code>$ cd New-Elite</code></li>
<li><code>$ ls</code></li>
<li><code>$ python2 dark.py</code></li>
</ul>
<br />
<br />
<img src="https://github.com/MrDebo/New-Elite/blob/master/Screenshot_2020-03-07-15-10-58-762_com.termux-picsay.png" />
